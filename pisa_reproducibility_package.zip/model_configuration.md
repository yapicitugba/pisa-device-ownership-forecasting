# Model Configuration Details

The study compared four forecasting models:

- LSTM
- GRU
- ARIMA
- Prophet

## LSTM and GRU Configuration

- Units: 50
- Learning rate: 0.001
- Epochs: 50
- Batch size: 16
- Dropout: 0.0
- Optimizer: Adam
- Loss function: Mean Squared Error (MSE)
- Lookback window: Three time steps

## Robustness Assessment

To assess stability under sparse longitudinal conditions, LSTM and GRU models were retrained using five different random seed initializations. Performance metrics were summarized using mean ± standard deviation values.

## Naïve Persistence Baseline

A Naïve Persistence Baseline was included as a simple benchmark. In this approach, the most recent observed value was carried forward as the next-cycle projection:

ŷ(t+1) = y(t)

This baseline was used to evaluate whether machine learning models provided additional forecasting contribution beyond a simple continuation of the latest observed trend.
