# PISA Digital Device Ownership Forecasting – Reproducibility Package

This repository provides supplementary reproducibility materials for the manuscript:

**Comparative Estimation of Digital Device Ownership via Time Series Models Based on PISA Data: LSTM, GRU, ARIMA and Prophet Models**

The purpose of this repository is to document the preprocessing workflow, category harmonization procedures, model configuration details, and pseudocode used in the study. Raw PISA data are not redistributed in this repository. The original PISA datasets should be obtained from the official OECD PISA data repository.

## Repository Contents

- `preprocessing_workflow.md`: Overview of the preprocessing and forecasting workflow.
- `category_harmonization_notes.md`: Notes on category standardization and proportional redistribution.
- `model_configuration.md`: Model settings and hyperparameters used in the study.
- `pseudocode.md`: Pseudocode-style description of the analytical workflow.
- `supplementary_tables/`: Supplementary tables for variable mapping, category harmonization, and missing ratios.

## Data Availability

The PISA datasets are publicly available through the official OECD PISA data repository. Users should download the relevant PISA cycle datasets directly from OECD and apply the preprocessing steps described in this repository.

## Important Note

This repository is intended to improve methodological transparency and reproducibility. It does not include raw student-level PISA data.
