# PISA Digital Device Ownership Forecasting – Full Code Package

This repository contains reproducible Python code for the manuscript:

**Comparative Estimation of Digital Device Ownership via Time Series Models Based on PISA Data: LSTM, GRU, ARIMA and Prophet Models**

## What this code covers

- Loading harmonized PISA device ownership data
- Missing value handling using interpolation and mean substitution
- Chronological train/test split
- LSTM and GRU model training
- ARIMA and Prophet model training
- Repeated seed robustness analysis for LSTM and GRU
- Naïve Persistence Baseline comparison
- Evaluation using MAE, MSE, RMSE, R², and DTW
- Recursive exploratory projections for 2025, 2028, and 2031
- Figure and table generation

## Data

Raw PISA data are not redistributed. Download the original PISA datasets from OECD.

Expected input file:

```text
data/harmonized_pisa_device_ownership.csv
```

Expected columns:

```text
country,cycle,device,category,value,CULTPOS,HOMEPOS,HEDRES,PAREDINT,WEALTH
```

Example:

```text
Türkiye,2006,computer,None,59.4,-0.001304,-1.058728,-0.653613,8.648,-1.058728
```

## Installation

```bash
pip install -r requirements.txt
```

## Run

```bash
python src/run_analysis.py --input data/harmonized_pisa_device_ownership.csv --target_country "Türkiye"
```

Outputs:

```text
outputs/tables/
outputs/figures/
```
