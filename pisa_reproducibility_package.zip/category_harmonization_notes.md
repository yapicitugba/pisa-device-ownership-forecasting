# Category Harmonization Notes

Digital device ownership variables were standardized into common longitudinal categories:

- None
- One
- Two
- Three or more

When category structures were already identical across PISA cycles, direct mapping was applied.

When category definitions differed across cycles, proportional reallocation procedures based on neighboring cycle distributions were applied to maintain temporal comparability.

## Worked Example

In some PISA cycles, desktop computer ownership categories were reported as:

- None
- 1 or 2
- 3–5
- More than 5

In other cycles, ownership categories were reported as:

- None
- One
- Two
- Three or more

For cycles where “1 or 2” appeared as a combined category, this category was proportionally redistributed into “One” and “Two” categories based on the observed distribution ratios in neighboring harmonized cycles.

Similarly, “3–5” and “More than 5” were aggregated into the harmonized “Three or more” category.

This procedure did not remove or artificially generate observations. Instead, it preserved the total category proportion while transforming the category structure into a comparable longitudinal format.
