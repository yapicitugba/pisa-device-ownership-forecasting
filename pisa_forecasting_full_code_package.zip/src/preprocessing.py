import pandas as pd
import numpy as np


def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {
        "country", "cycle", "device", "category", "value",
        "CULTPOS", "HOMEPOS", "HEDRES", "PAREDINT", "WEALTH"
    }
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    df["cycle"] = df["cycle"].astype(int)
    return df


def handle_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """
    Handles missing values using:
    1. Linear interpolation across adjacent PISA cycles,
    2. Mean substitution when interpolation is not sufficient,
    3. Final global mean substitution if any unresolved missing values remain.
    """
    df = df.sort_values(["country", "device", "category", "cycle"]).copy()
    numeric_cols = ["value", "CULTPOS", "HOMEPOS", "HEDRES", "PAREDINT", "WEALTH"]

    def fill_group(group):
        group = group.sort_values("cycle").copy()
        for col in numeric_cols:
            group[col] = group[col].interpolate(method="linear", limit_direction="both")
            if group[col].isna().any():
                group[col] = group[col].fillna(group[col].mean())
        return group

    df = df.groupby(["country", "device", "category"], group_keys=False).apply(fill_group)

    for col in numeric_cols:
        if df[col].isna().any():
            df[col] = df[col].fillna(df[col].mean())

    return df


def minmax_scale_by_series(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    def scale(group):
        vmin = group["value"].min()
        vmax = group["value"].max()
        group["value_min"] = vmin
        group["value_max"] = vmax
        if np.isclose(vmax, vmin):
            group["value_scaled"] = 0.0
        else:
            group["value_scaled"] = (group["value"] - vmin) / (vmax - vmin)
        return group

    return df.groupby(["country", "device", "category"], group_keys=False).apply(scale)


def inverse_scale(value_scaled: float, vmin: float, vmax: float) -> float:
    return value_scaled * (vmax - vmin) + vmin
