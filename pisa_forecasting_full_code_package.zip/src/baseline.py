def naive_persistence_forecast(last_observed_value: float, steps: int = 1) -> list[float]:
    return [last_observed_value for _ in range(steps)]
