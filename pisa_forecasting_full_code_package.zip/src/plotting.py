import os
import matplotlib.pyplot as plt


def plot_metric_bars(metrics_df, output_dir):
    os.makedirs(output_dir, exist_ok=True)

    for metric in ["R2", "DTW", "MAE", "MSE", "RMSE"]:
        if metric not in metrics_df.columns:
            continue

        fig, ax = plt.subplots(figsize=(8, 5))
        ax.bar(metrics_df["Model"], metrics_df[metric])
        ax.set_title(f"{metric} scores for LSTM, GRU, ARIMA, Prophet, and Baseline", fontweight="normal")
        ax.set_xlabel("Model")
        ax.set_ylabel(metric)
        fig.tight_layout()
        fig.savefig(os.path.join(output_dir, f"{metric.lower()}_scores.png"), dpi=300)
        plt.close(fig)


def plot_projection(series_df, projection_df, output_path, title):
    fig, ax = plt.subplots(figsize=(9, 6))
    ax.plot(series_df["cycle"], series_df["value"], marker="o", label="Observed")
    ax.plot(projection_df["cycle"], projection_df["projection"], marker="o", linestyle="--", label="Exploratory projection")
    ax.set_title(title, fontweight="normal")
    ax.set_xlabel("PISA Cycle")
    ax.set_ylabel("Ownership rate (%)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_path, dpi=300)
    plt.close(fig)
