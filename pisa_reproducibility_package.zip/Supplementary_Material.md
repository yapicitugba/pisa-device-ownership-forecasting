# Supplementary Material

## Additional Reproducibility and Harmonization Details

This supplementary file provides additional methodological details regarding variable harmonization, preprocessing procedures, and missing observation summaries used in the study in order to improve transparency and reproducibility.

## Supplementary Table S1. Original PISA Variables and Harmonized Variables Used in the Study

|   PISA Cycle | Original Variable Name / Item Label                        | Description                         | Harmonized Variable   |
|-------------:|:-----------------------------------------------------------|:------------------------------------|:----------------------|
|         2006 | How many computers / Q14c                                  | Number of computers at home         | Computer Ownership    |
|         2009 | How many computers                                         | Number of computers at home         | Computer Ownership    |
|         2012 | How many – computers                                       | Number of computers at home         | Computer Ownership    |
|         2015 | Computers (desktop computer, portable laptop, or notebook) | Number of computers at home         | Computer Ownership    |
|         2018 | Computers (desktop computer, portable laptop, or notebook) | Number of computers at home         | Computer Ownership    |
|         2022 | Desktop computers                                          | Number of desktop computers at home | Computer Ownership    |

## Supplementary Table S2. Examples of Category Harmonization Procedures Across PISA Cycles

| PISA Cycle   | Original Category Structure      | Harmonized Category Structure    | Harmonization Procedure                               |
|:-------------|:---------------------------------|:---------------------------------|:------------------------------------------------------|
| 2006         | None                             | None                             | Direct mapping                                        |
| 2006         | 1 or 2                           | One / Two                        | Proportional redistribution                           |
| 2006         | 3–5                              | Three or more                    | Category aggregation                                  |
| 2006         | More than 5                      | Three or more                    | Category aggregation                                  |
| 2009–2022    | None / One / Two / Three or more | None / One / Two / Three or more | Direct harmonization where categories were consistent |

## Supplementary Table S3. Missing Observation Ratios Across Selected PISA Cycles

|   PISA Cycle |   Missing Ratio (%) |
|-------------:|--------------------:|
|         2006 |                 3.6 |
|         2009 |                 1   |
|         2012 |                 2   |
|         2015 |                 1.7 |
|         2018 |                 1.7 |
|         2022 |                 1.4 |

**Note:** Missing observation ratios correspond to selected digital device ownership variables used during preprocessing and harmonization procedures.
