# Pseudocode

```text
1. Load PISA datasets for selected cycles.
2. Filter selected countries:
   - Türkiye
   - Poland
   - Hungary
   - Mexico
   - Chile

3. Select digital device ownership variables:
   - Computer ownership
   - Television ownership
   - Mobile phone ownership

4. Select socio-economic variables:
   - CULTPOS
   - HOMEPOS
   - HEDRES
   - PAREDINT
   - WEALTH

5. Harmonize ownership categories:
   IF category structure is identical:
       Apply direct mapping.
   ELSE IF combined category exists:
       Apply proportional redistribution based on neighboring cycle distributions.
   ELSE IF upper categories are split:
       Aggregate into "Three or more".

6. Handle missing values:
   - Use interpolation where adjacent cycle values are available.
   - Use proportional adjustment where category harmonization requires redistribution.
   - Ensure no unresolved missing values remain in final modeling dataset.

7. Construct longitudinal country-cycle time series.

8. Split data chronologically:
   - Training: 2006–2018
   - Testing: 2022

9. Train ARIMA, Prophet, LSTM, and GRU models.

10. Evaluate models using:
    - MAE
    - MSE
    - RMSE
    - R²
    - DTW

11. Conduct robustness assessment:
    - Repeated seed runs for LSTM and GRU
    - Naïve Persistence Baseline comparison

12. Generate recursive exploratory projections:
    - 2025
    - 2028
    - 2031
```
