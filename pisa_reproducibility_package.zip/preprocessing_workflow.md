# Preprocessing and Forecasting Workflow

The general preprocessing and forecasting workflow used in the study can be summarized as follows:

1. Downloading and filtering PISA cycle datasets.
2. Selecting digital device ownership and socio-economic variables.
3. Documenting original variable names and category structures.
4. Harmonizing category structures across cycles.
5. Handling missing values using interpolation and proportional adjustment procedures.
6. Constructing country-cycle-level longitudinal time series.
7. Training and evaluating forecasting models.
8. Performing robustness analyses using repeated seed initializations and comparisons with the Naïve Persistence Baseline.
9. Generating recursive exploratory projections for 2025, 2028, and 2031.

The workflow was designed to preserve temporal ordering and improve reproducibility under sparse longitudinal conditions.
