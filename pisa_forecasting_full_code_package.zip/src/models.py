import numpy as np
import pandas as pd

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, GRU, Dense
from tensorflow.keras.optimizers import Adam

from statsmodels.tsa.arima.model import ARIMA

try:
    from prophet import Prophet
except Exception:
    Prophet = None


def create_sequences(array: np.ndarray, lookback: int):
    X, y = [], []
    for i in range(len(array) - lookback):
        X.append(array[i:i + lookback])
        y.append(array[i + lookback, 0])
    return np.array(X), np.array(y)


def build_lstm(input_shape, units=50, learning_rate=0.001):
    model = Sequential()
    model.add(LSTM(units, input_shape=input_shape))
    model.add(Dense(1))
    model.compile(optimizer=Adam(learning_rate=learning_rate), loss="mse")
    return model


def build_gru(input_shape, units=50, learning_rate=0.001):
    model = Sequential()
    model.add(GRU(units, input_shape=input_shape))
    model.add(Dense(1))
    model.compile(optimizer=Adam(learning_rate=learning_rate), loss="mse")
    return model


def train_neural_model(model_type, train_array, lookback, seed, units=50, learning_rate=0.001, epochs=50, batch_size=16):
    import tensorflow as tf

    np.random.seed(seed)
    tf.random.set_seed(seed)

    X_train, y_train = create_sequences(train_array, lookback)
    if len(X_train) == 0:
        raise ValueError("Not enough data points for the selected lookback window.")

    input_shape = (X_train.shape[1], X_train.shape[2])

    if model_type.lower() == "lstm":
        model = build_lstm(input_shape, units, learning_rate)
    elif model_type.lower() == "gru":
        model = build_gru(input_shape, units, learning_rate)
    else:
        raise ValueError("model_type must be LSTM or GRU.")

    model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, verbose=0)
    return model


def one_step_neural_forecast(model, train_array, lookback):
    window = train_array[-lookback:]
    pred = model.predict(window.reshape(1, lookback, train_array.shape[1]), verbose=0)
    return float(pred[0, 0])


def recursive_neural_forecast(model, full_array, lookback, future_covariates):
    window = full_array[-lookback:].copy()
    preds = []

    for cov in future_covariates:
        pred = float(model.predict(window.reshape(1, lookback, full_array.shape[1]), verbose=0)[0, 0])
        preds.append(pred)
        next_row = np.concatenate([[pred], cov])
        window = np.vstack([window[1:], next_row])

    return preds


def fit_arima_forecast(train_values, steps=1):
    candidate_orders = [(1, 1, 0), (1, 0, 0), (0, 1, 1), (1, 1, 1)]
    best = None
    best_aic = np.inf

    for order in candidate_orders:
        try:
            model = ARIMA(train_values, order=order).fit()
            if model.aic < best_aic:
                best_aic = model.aic
                best = model
        except Exception:
            pass

    if best is None:
        raise RuntimeError("ARIMA fitting failed.")

    return np.asarray(best.forecast(steps=steps), dtype=float)


def fit_prophet_forecast(cycles, values, future_cycles):
    if Prophet is None:
        raise ImportError("Prophet is not installed.")

    df = pd.DataFrame({
        "ds": pd.to_datetime([f"{int(c)}-01-01" for c in cycles]),
        "y": values,
    })

    model = Prophet()
    model.fit(df)

    future = pd.DataFrame({
        "ds": pd.to_datetime([f"{int(c)}-01-01" for c in future_cycles])
    })

    forecast = model.predict(future)
    return forecast["yhat"].to_numpy(dtype=float)
