import argparse
import os
import numpy as np
import pandas as pd

from config import RANDOM_SEEDS, TRAIN_CYCLES, TEST_CYCLE, FORECAST_CYCLES, LOOKBACK, SOCIOECONOMIC_COLUMNS
from preprocessing import load_data, handle_missing_values, minmax_scale_by_series, inverse_scale
from metrics import evaluate
from baseline import naive_persistence_forecast
from models import train_neural_model, one_step_neural_forecast, recursive_neural_forecast, fit_arima_forecast, fit_prophet_forecast
from plotting import plot_metric_bars, plot_projection


def feature_array(series):
    return series[["value_scaled"] + SOCIOECONOMIC_COLUMNS].to_numpy(dtype=float)


def future_covariates(series, future_cycles):
    last_cov = series.sort_values("cycle")[SOCIOECONOMIC_COLUMNS].iloc[-1].to_numpy(dtype=float)
    return np.tile(last_cov, (len(future_cycles), 1))


def analyze_one_series(df, country, device, category):
    series = df[
        (df["country"] == country) &
        (df["device"] == device) &
        (df["category"] == category)
    ].sort_values("cycle").copy()

    train = series[series["cycle"].isin(TRAIN_CYCLES)]
    test = series[series["cycle"] == TEST_CYCLE]

    if len(train) < LOOKBACK + 1 or test.empty:
        raise ValueError("Insufficient data for this series.")

    train_array = feature_array(train)
    full_array = feature_array(series)

    y_test = test["value"].to_numpy(dtype=float)
    vmin = float(series["value_min"].iloc[0])
    vmax = float(series["value_max"].iloc[0])

    rows = []
    saved_models = {}

    for model_name in ["LSTM", "GRU"]:
        seed_predictions = []
        first_model = None

        for seed in RANDOM_SEEDS:
            model = train_neural_model(model_name, train_array, LOOKBACK, seed)
            pred_scaled = one_step_neural_forecast(model, train_array, LOOKBACK)
            pred = inverse_scale(pred_scaled, vmin, vmax)
            seed_predictions.append(pred)
            if first_model is None:
                first_model = model

        mean_pred = float(np.mean(seed_predictions))
        metrics = evaluate(y_test, [mean_pred])
        metrics.update({
            "Model": model_name,
            "Prediction": mean_pred,
            "Prediction_SD": float(np.std(seed_predictions, ddof=1)),
        })
        rows.append(metrics)
        saved_models[model_name] = first_model

    # ARIMA
    try:
        arima_pred = float(fit_arima_forecast(train["value"].to_numpy(dtype=float), steps=1)[0])
        metrics = evaluate(y_test, [arima_pred])
        metrics.update({"Model": "ARIMA", "Prediction": arima_pred, "Prediction_SD": np.nan})
        rows.append(metrics)
    except Exception as e:
        print(f"ARIMA skipped for {device}-{category}: {e}")

    # Prophet
    try:
        prophet_pred = float(fit_prophet_forecast(train["cycle"], train["value"], [TEST_CYCLE])[0])
        metrics = evaluate(y_test, [prophet_pred])
        metrics.update({"Model": "Prophet", "Prediction": prophet_pred, "Prediction_SD": np.nan})
        rows.append(metrics)
    except Exception as e:
        print(f"Prophet skipped for {device}-{category}: {e}")

    # Naive Persistence Baseline
    naive_pred = float(naive_persistence_forecast(train["value"].iloc[-1], 1)[0])
    metrics = evaluate(y_test, [naive_pred])
    metrics.update({"Model": "Naive Persistence Baseline", "Prediction": naive_pred, "Prediction_SD": np.nan})
    rows.append(metrics)

    metrics_df = pd.DataFrame(rows)

    # Recursive 2025, 2028, 2031 projections using GRU
    cov_future = future_covariates(series, FORECAST_CYCLES)
    future_scaled = recursive_neural_forecast(saved_models["GRU"], full_array, LOOKBACK, cov_future)
    projections = [inverse_scale(x, vmin, vmax) for x in future_scaled]

    projection_df = pd.DataFrame({
        "country": country,
        "device": device,
        "category": category,
        "cycle": FORECAST_CYCLES,
        "projection": projections,
        "model": "GRU",
    })

    return series, metrics_df, projection_df


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--target_country", default="Türkiye")
    parser.add_argument("--output", default="outputs")
    args = parser.parse_args()

    table_dir = os.path.join(args.output, "tables")
    fig_dir = os.path.join(args.output, "figures")
    os.makedirs(table_dir, exist_ok=True)
    os.makedirs(fig_dir, exist_ok=True)

    df = load_data(args.input)
    df = handle_missing_values(df)
    df = minmax_scale_by_series(df)

    target = df[df["country"] == args.target_country]
    all_metrics = []
    all_projections = []

    for device in sorted(target["device"].unique()):
        for category in sorted(target["category"].unique()):
            try:
                series, metrics, projections = analyze_one_series(df, args.target_country, device, category)
                metrics["country"] = args.target_country
                metrics["device"] = device
                metrics["category"] = category
                all_metrics.append(metrics)
                all_projections.append(projections)

                fig_name = f"projection_{device}_{category}.png".replace(" ", "_")
                plot_projection(
                    series,
                    projections,
                    os.path.join(fig_dir, fig_name),
                    f"Trends and 2031 Estimation of {device.title()} Ownership ({category})"
                )
            except Exception as e:
                print(f"Skipped {device}-{category}: {e}")

    metrics_all = pd.concat(all_metrics, ignore_index=True)
    projections_all = pd.concat(all_projections, ignore_index=True)

    metrics_all.to_csv(os.path.join(table_dir, "model_metrics_by_series.csv"), index=False)
    projections_all.to_csv(os.path.join(table_dir, "exploratory_projections_2025_2028_2031.csv"), index=False)

    summary = metrics_all.groupby("Model")[["MAE", "MSE", "RMSE", "R2", "DTW"]].mean().reset_index()
    summary.to_csv(os.path.join(table_dir, "model_metrics_summary.csv"), index=False)

    plot_metric_bars(summary, fig_dir)

    print("Analysis completed.")
    print(f"Tables: {table_dir}")
    print(f"Figures: {fig_dir}")


if __name__ == "__main__":
    main()
